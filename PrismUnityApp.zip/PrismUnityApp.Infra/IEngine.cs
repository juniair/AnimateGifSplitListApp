﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrismUnityApp.Infra
{
    public interface IEngine
    {
        ObservableCollection<ImageInfo> Run(string path);
    }

    public class ImageInfo
    {
        public byte[] ImageSource { get; set; }
        public string ImageName { get; set; }
        public int Duration { get; set; }
    }
}
