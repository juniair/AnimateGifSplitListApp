﻿using PrismUnityApp.Infra;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Drawing.Imaging;
using System.IO;
using System.Drawing;
using System.Data;
using System.Windows;
using System.Reflection;

namespace PrismUnityApp.Engine
{
    public class Engine : IEngine
    {

        private const int PROPERTY_TAG_FRAME_DELAY = 0x5100;

        private int frameCount;
        private bool animated;
        private int[] frameDelay;

        private IList<ImageInfo> imageInfoList;
        private IList<byte[]> imageStreamDataList;

        private Dictionary<Guid, ImageFormat> guidToImageFormatMap;


        public ObservableCollection<ImageInfo> Run(string path)
        {

            if (!File.Exists(path))
            {
                MessageBox.Show("파일이 존재 하지 않습니다.");
                return null;
            }

            guidToImageFormatMap = new Dictionary<Guid, ImageFormat>()
            {
                { ImageFormat.Bmp.Guid,  ImageFormat.Bmp},
                { ImageFormat.Gif.Guid,  ImageFormat.Png},
                { ImageFormat.Icon.Guid, ImageFormat.Png},
                { ImageFormat.Jpeg.Guid, ImageFormat.Jpeg},
                { ImageFormat.Png.Guid,  ImageFormat.Png}
            };
            imageStreamDataList = new List<byte[]>();
            imageInfoList = new List<ImageInfo>();

            Image image = Image.FromFile(path);

            ImageFormat imageFormat = null;
            Guid imageGuid = image.RawFormat.Guid;

            foreach (KeyValuePair<Guid, ImageFormat> pair in guidToImageFormatMap)
            {
                if (imageGuid == pair.Key)
                {
                    imageFormat = pair.Value;
                    break;
                }
            }

            if (imageFormat == null)
            {
                throw new NoNullAllowedException("Unable to determine image format");
            }


            animated = ImageAnimator.CanAnimate(image);

            if(animated)
            {
                frameCount = image.GetFrameCount(FrameDimension.Time);
                PropertyItem freamDelayItem = image.GetPropertyItem(PROPERTY_TAG_FRAME_DELAY);

                if(freamDelayItem != null)
                {
                    byte[] values = freamDelayItem.Value;
                    frameDelay = new int[frameCount];

                    for(int i = 0; i < frameCount; i++)
                    {
                        frameDelay[i] = values[i * 4] + 256 * values[i * 4 + 1] + 256 * 256 * values[i * 4 + 2] + 256 * 256 * 256 * values[i * 4 + 3];
                        image.SelectActiveFrame(FrameDimension.Time, i);
                        using (MemoryStream memoryStream = new MemoryStream())
                        {
                            image.Save(memoryStream, imageFormat);
                            imageStreamDataList.Add(memoryStream.ToArray());
                        }
                    }
                }
            }
            else
            {
                frameCount = 1;
                image.SelectActiveFrame(FrameDimension.Time, 0);
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    image.Save(memoryStream, imageFormat);
                    imageStreamDataList.Add(memoryStream.ToArray());
                }
            }

            if (frameDelay == null)
            {
                frameDelay = new int[frameCount];
            }

            for (int i = 0; i < frameCount; i++)
            {
                imageInfoList.Add(new ImageInfo
                {
                    ImageSource = imageStreamDataList[i],
                    ImageName = string.Format("Frame[{0}]", i),
                    Duration = frameDelay[i]
                });
            }


            return new ObservableCollection<ImageInfo>(imageInfoList);
        }

        private Image makeImage(byte[] imageBytes)
        {
            if (imageBytes == null || imageBytes.Length == 0)
            {
                return null;
            }

            try
            {
                using(MemoryStream memoryStream = new MemoryStream(imageBytes))
                {
                    using (Image image = Image.FromStream(memoryStream))
                    {
                        return image;
                    }
                }
            }
            catch(Exception e)
            {
                MessageBox.Show(
                    "Error type: " + e.GetType().ToString() + "\n" +
                    "Message: " + e.Message,
                    "Error in " + MethodBase.GetCurrentMethod().Name
                    );
            }

            return null;
        }
    }
}
