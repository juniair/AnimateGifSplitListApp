﻿using Microsoft.Practices.Unity;
using Prism.Modularity;
using Prism.Regions;
using System;

namespace PrismUnityApp.AnimatedGifSplitList
{
    [ModuleDependency("EngineModule")]
    public class AnimatedGifSplitListModule : IModule
    {
        IRegionManager _regionManager;
        IUnityContainer _container;


        public AnimatedGifSplitListModule(IUnityContainer container, IRegionManager regionManager)
        {
            _regionManager = regionManager;
            _container = container;
        }

        public void Initialize()
        {
            
            _regionManager.RegisterViewWithRegion("ContentRegion", typeof(Views.SplitImageList));
        }
    }
}