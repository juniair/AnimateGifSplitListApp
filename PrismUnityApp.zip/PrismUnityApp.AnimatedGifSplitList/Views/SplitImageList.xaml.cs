﻿using System.Windows.Controls;

namespace PrismUnityApp.AnimatedGifSplitList.Views
{
    /// <summary>
    /// Interaction logic for SplitImageList
    /// </summary>
    public partial class SplitImageList : UserControl
    {
        public SplitImageList()
        {
            InitializeComponent();
        }
    }
}
