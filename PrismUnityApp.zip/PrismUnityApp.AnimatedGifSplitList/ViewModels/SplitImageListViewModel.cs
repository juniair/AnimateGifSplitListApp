﻿using Prism.Commands;
using Prism.Mvvm;
using PrismUnityApp.Infra;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;

namespace PrismUnityApp.AnimatedGifSplitList.ViewModels
{
    public class SplitImageListViewModel : BindableBase
    {
        IEngine Engine { get; set; }
        private ObservableCollection<ImageInfo> frameList;
        public ObservableCollection<ImageInfo> FrameList { get { return frameList; } }

        public ICommand SplitImageCommand { get; set; }

        private string fileName;
        public string FileName
        {
            get { return fileName; }
            set { SetProperty(ref fileName, value); }
        }
        public SplitImageListViewModel(IEngine engine)
        {

            FileName = "test.gif";
            Engine = engine;
            frameList = Engine.Run(FileName);
            SplitImageCommand = new DelegateCommand<object>(run);
        }

        private void run(object obj)
        {
            frameList = Engine.Run(FileName);
        }
    }
}
